# Laborator: funcții, metode și importuri pe web
# Student: Gherman Laurențiu
import json
import urllib.parse
import re
from html.parser import HTMLParser
import requests
import time
import urllib.parse
import hashlib
import socket
import ssl

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# ex.35
def descompune_url(url: str):
    """Afișează părțile componente ale unui URL."""
    parti = urllib.parse.urlparse(url)
    print("scheme:", parti.scheme)
    print("netloc:", parti.netloc)
    print("path:", parti.path)
    print("query:", parti.query)
    print("fragment:", parti.fragment)


descompune_url("https://cybercor.org/path?x=1#top")

# ex.36
def uneste_linkuri(base: str, linkuri: list) -> list:
    """Transformă legăturile relative în URL-uri complete, pornind de la base."""
    return [urllib.parse.urljoin(base, link) for link in linkuri]


relative = ["/about", "contact.html", "../index.html"]
for relativ, complet in zip(relative, uneste_linkuri(BASE_URL, relative)):
    print(relativ, "->", complet)

# ex.37
def extract_links(html: str) -> list:
    """Returnează legăturile (href) din codul html, fără duplicate."""
    linkuri = re.findall(r'href="([^"]+)"', html)
    return list(dict.fromkeys(linkuri))


time.sleep(1) 
raspuns = requests.get(BASE_URL, timeout=TIMEOUT)
linkuri = extract_links(raspuns.text)
print("Număr de legături:", len(linkuri))
for link in linkuri:
    print(link)

    # ex.38
def split_links(links: list, domain: str):
    """Împarte legăturile în două liste: de pe același domeniu și către alte site-uri."""
    interne = []
    externe = []
    baza = "https://" + domain
    for link in links:
        complet = urllib.parse.urljoin(baza, link)
        if urllib.parse.urlparse(complet).netloc == domain:
            interne.append(complet)
        else:
            externe.append(complet)
    return interne, externe


interne, externe = split_links(linkuri, "cybercor.org")
print("Legături interne:", len(interne))
for link in interne:
    print("  ", link)
print("Legături externe:", len(externe))
for link in externe:
    print("  ", link)

# ex.39
class ImageFinder(HTMLParser):
    """Colectează atributul src al fiecărui tag <img>."""

    def __init__(self):
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        if tag == "img":
            for nume, valoare in attrs:
                if nume == "src":
                    self.images.append(valoare)


time.sleep(1)
raspuns = requests.get(BASE_URL, timeout=TIMEOUT)

parser = ImageFinder()
parser.feed(raspuns.text)
print("Imagini găsite:", len(parser.images))
for imagine in parser.images:
    print(imagine)

    # ex.40
def page_fingerprint(url: str) -> str:
    """Returnează amprenta SHA-256 a conținutului paginii de la adresa url."""
    response = requests.get(url, timeout=TIMEOUT)
    return hashlib.sha256(response.content).hexdigest()


time.sleep(1)
amprenta1 = page_fingerprint(BASE_URL)
print("Amprenta 1:", amprenta1)

time.sleep(1)
amprenta2 = page_fingerprint(BASE_URL)
print("Amprenta 2:", amprenta2)

print("Identice:", amprenta1 == amprenta2)

# Amprentele ar fi diferite daca pagina s-a schimbat intre cele doua cereri
# (continut nou, un contor, o data sau un token generat de server).

# ex.41
def salveaza_antete(url: str, fisier: str = "headers.json"):
    """Descarcă pagina și salvează antetele ei în fișierul JSON dat."""
    response = requests.get(url, timeout=TIMEOUT)
    with open(fisier, "w", encoding="utf-8") as f:
        json.dump(dict(response.headers), f, indent=2)


def incarca_antete(fisier: str = "headers.json") -> dict:
    """Citește antetele salvate dintr-un fișier JSON și le returnează ca dicționar."""
    with open(fisier, "r", encoding="utf-8") as f:
        return json.load(f)


time.sleep(1)
salveaza_antete(BASE_URL)

antete = incarca_antete()
print("Server:", antete["Server"])

# ex.42
def resolve(hostname: str) -> str:
    """Returnează adresa IP a domeniului hostname, prin interogare DNS."""
    return socket.gethostbyname(hostname)


print("Adresa IP pentru cybercor.org:", resolve("cybercor.org"))
# ex.43
def cert_days_left(hostname: str) -> int:
    """Returnează câte zile mai sunt până la expirarea certificatului SSL al domeniului."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            certificat = ssock.getpeercert()
    expira = ssl.cert_time_to_seconds(certificat["notAfter"])
    return int((expira - time.time()) / 86400)


time.sleep(1)
print("Zile rămase până la expirarea certificatului:", cert_days_left("cybercor.org"))
# handle_starttag() este apelata automat de parser, in interiorul metodei feed()
# de fiecare data cand intalneste un tag de deschidere.