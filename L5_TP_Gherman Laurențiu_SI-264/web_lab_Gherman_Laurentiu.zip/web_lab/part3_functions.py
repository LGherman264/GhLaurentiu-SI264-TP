# Laborator: funcții, metode și importuri pe web
# Student: Gherman Laurențiu
 
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde
import requests
import time

# ex.21
def fetch(url):
    """Returnează obiectul răspuns pentru adresa url."""
    response = requests.get(url, timeout=TIMEOUT)
    return response


raspuns = fetch(BASE_URL)
print("Cod de stare:", raspuns.status_code)

# ex.22
def get_status(url):
    """Returnează codul de stare HTTP pentru adresa url."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code


time.sleep(1)
print("/:", get_status(BASE_URL + "/"))

time.sleep(1)
print("/robots.txt:", get_status(BASE_URL + "/robots.txt"))

time.sleep(1)
print("/sitemap.xml:", get_status(BASE_URL + "/sitemap.xml"))
# ex.23
def fetch(url, timeout=10):
    """Returnează obiectul răspuns pentru adresa url, cu timeout în secunde."""
    response = requests.get(url, timeout=timeout)
    return response


time.sleep(1)
r1 = fetch(BASE_URL)
print("Cu timeout implicit (10):", r1.status_code)

time.sleep(1)
r2 = fetch(BASE_URL, timeout=3)
print("Cu timeout=3:", r2.status_code)

# ex.24
def get_title(html):
    """Returnează titlul paginii din șirul html, sau None dacă lipsește."""
    if "<title>" in html and "</title>" in html:
        start = html.find("<title>") + len("<title>")
        end = html.find("</title>")
        return html[start:end].strip()
    return None


time.sleep(1)
raspuns = fetch(BASE_URL)
print("Titlu:", get_title(raspuns.text))

# ex.25

def get_title(html):
    """Extrage titlul paginii dintr-un șir HTML.

    Parametri:
        html (str): codul HTML al paginii.

    Returnează:
        str: textul dintre <title> și </title>, fără spații la capete,
        sau None dacă pagina nu are titlu.
    """
    if "<title>" in html and "</title>" in html:
        start = html.find("<title>") + len("<title>")
        end = html.find("</title>")
        return html[start:end].strip()
    return None


#help(get_title)

# ex.26
def fetch(url: str, timeout: int = 10) -> requests.Response:
    """Returnează obiectul răspuns pentru adresa url, cu timeout în secunde."""
    response = requests.get(url, timeout=timeout)
    return response


def get_status(url: str) -> int:
    """Returnează codul de stare HTTP pentru adresa url."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code


def get_title(html: str) -> str | None:
    """Extrage titlul paginii dintr-un șir HTML, sau None dacă lipsește."""
    if "<title>" in html and "</title>" in html:
        start = html.find("<title>") + len("<title>")
        end = html.find("</title>")
        return html[start:end].strip()
    return None


#get_status(123)

# Adnotările de tip nu m-au oprit: Python nu le verifică la rulare.
# Eroarea (MissingSchema) vine din requests, care nu acceptă 123 ca adresă, nu din adnotarea str.
# ex.27
def page_exists(url: str) -> bool:
    """Returnează True dacă pagina răspunde cu succes, altfel False."""
    try:
        response = requests.get(url, timeout=TIMEOUT)
        return response.ok
    except requests.RequestException:
        return False


time.sleep(1)  # pauză între cereri
print(page_exists(BASE_URL))

print(page_exists("https://this-domain-does-not-exist.invalid"))

# ex.28
def check_paths(base: str, paths: list) -> dict:
    """Returnează un dicționar {cale: cod_de_stare} pentru fiecare cale din listă."""
    rezultate = {}
    for cale in paths:
        time.sleep(1)  # pauză între cereri
        rezultate[cale] = get_status(base + cale)
    return rezultate


rezultat = check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml"])
print(rezultat)

# ex.29
def get_header(url: str, name: str, default: str = "lipsește") -> str:
    """Returnează valoarea antetului name pentru adresa url, sau default dacă lipsește."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.headers.get(name, default)


time.sleep(1) 
print("Server:", get_header(BASE_URL, name="Server"))

time.sleep(1)
print("X-Nu-Exista:", get_header(BASE_URL, name="X-Nu-Exista"))

time.sleep(1)
print("X-Nu-Exista (default propriu):", get_header(BASE_URL, name="X-Nu-Exista", default="nu e setat"))

# ex.30
def security_headers(url: str) -> dict:
    """Verifică prezența a cinci antete de securitate și returnează {antet: True/False}."""
    antete = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy",
    ]
    response = requests.get(url, timeout=TIMEOUT)
    rezultat = {}
    for antet in antete:
        rezultat[antet] = antet in response.headers
    return rezultat


time.sleep(1)
rezultate = security_headers(BASE_URL)
for antet, prezent in rezultate.items():
    print(antet + ":", prezent)

    # ex.31
def score_headers(results: dict) -> str:
    """Primește dicționarul din security_headers și returnează un șir precum '3/5'."""
    prezente = sum(results.values())
    return f"{prezente}/{len(results)}"

time.sleep(1)
print("Scor antete de securitate:", score_headers(security_headers(BASE_URL)))

# ex.32
def fetch_robots(base: str) -> str | None:
    """Returnează textul fișierului /robots.txt sau None dacă lipsește."""
    response = requests.get(base + "/robots.txt", timeout=TIMEOUT)
    if response.status_code == 200:
        return response.text
    return None


def disallowed_paths(robots_text: str | None) -> list:
    """Returnează lista valorilor Disallow: din textul robots.txt (listă goală pentru None)."""
    if robots_text is None:
        return []
    cai = []
    for linie in robots_text.splitlines():
        linie = linie.strip()
        if linie.lower().startswith("disallow:"):
            cai.append(linie.split(":", 1)[1].strip())
    return cai


time.sleep(1)  
robots = fetch_robots(BASE_URL)
print(disallowed_paths(robots))

print(disallowed_paths(None))  # funcționează și pentru None


# ex.33
def response_times(*urls):
    """Returnează un dicționar {url: secunde} cu timpul de răspuns pentru fiecare url."""
    rezultat = {}
    for url in urls:
        time.sleep(1) 
        start = time.perf_counter()
        requests.get(url, timeout=TIMEOUT)
        rezultat[url] = round(time.perf_counter() - start, 3)
    return rezultat


print(response_times(BASE_URL, ECHO_URL))

# ex.34
def log(message: str, **details):
    """Afișează mesajul urmat de fiecare detaliu, separate prin ' | '."""
    parti = [message]
    for cheie, valoare in details.items():
        parti.append(f"{cheie}={valoare}")
    print(" | ".join(parti))


log("verificat", url=BASE_URL, status=200)

# print() doar afiseaza valoarea pe ecran, iar functia nu da nimic inapoi
# return trimite valoarea apelantului
# care o poate salva, compara sau folosi mai departe