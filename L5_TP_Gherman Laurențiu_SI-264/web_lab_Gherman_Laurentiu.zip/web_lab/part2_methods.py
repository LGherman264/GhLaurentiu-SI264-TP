# Laborator: funcții, metode și importuri pe web
# Student: Gherman Laurențiu
 
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import requests
import time

# ex.9
response = requests.get(BASE_URL, timeout=TIMEOUT)

print(response.status_code)
print(response.ok)
print(response.url)
print(response.encoding) #toate sunt atribute

# ex.10

response.raise_for_status()
print("Pagina principală: OK")

time.sleep(1)

try:
    response = requests.get(BASE_URL + "/this-page-does-not-exist", timeout=TIMEOUT)
    response.raise_for_status()
except requests.HTTPError:
    print("Pagina nu a fost găsită (eroare HTTP), dar programul continuă.")
# Serverul a raspuns cu 200 si pentru o pagina inexistenta, deci raise_for_status() nu a ridicat exceptia.

    # ex.11
time.sleep(1)
response = requests.get(BASE_URL, timeout=TIMEOUT)
for nume, valoare in response.headers.items():
    print(f"{nume}: {valoare}")

    # ex.12
print("Server:", response.headers.get("Server", "lipsește"))
print("Content-Type:", response.headers.get("Content-Type", "lipsește"))

print("content-type (litere mici):", response.headers.get("content-type", "lipsește"))

# Se observă că și cu litere mici returnează aceeași valoare, deoarece antetele sunt insensibile la majuscule.

# ex.13
time.sleep(1)
nr = response.text.lower().count("cyber")
print("Cuvantul 'cyber' apare de", nr, "ori")

# Pot inlantui .lower() si .count() pentru ca .lower() returneaza un sir nou (str),
# Iar .count() este o metoda a sirurilor, deci se aplica direct pe rezultat.

# ex.14
time.sleep(1)

response = requests.get(BASE_URL, timeout=TIMEOUT)
html = response.text

if "<title>" in html and "</title>" in html:
    start = html.find("<title>") + len("<title>")
    end = html.find("</title>")
    titlu = html[start:end].strip()
    print("Titlu:", titlu)
else:
    print("Pagina nu are tag-ul <title>")

    # ex.15

    time.sleep(1)
lines = response.text.splitlines()
print("Numar de linii:", len(lines))

cea_mai_lunga = max(lines, key=len)
print("Lungimea celei mai lungi linii:", len(cea_mai_lunga))

#ex. 16
print("Conexiune securizată" if response.url.startswith("https://") else "Conexiune nesecurizată")
#ex. 17
time.sleep(1)

response = requests.get("http://cybercor.org", timeout=TIMEOUT)

for r in response.history:
    print(r.status_code, r.url)

print("URL final:", response.url)
print("Cod final:", response.status_code)

# ex.18
time.sleep(1)

r_head = requests.head(BASE_URL, timeout=TIMEOUT)
print("HEAD:", r_head.status_code, "- lungime conținut:", len(r_head.content))

time.sleep(1) 

r_get = requests.get(BASE_URL, timeout=TIMEOUT)
print("GET:", r_get.status_code, "- lungime conținut:", len(r_get.content))

# HEAD returnează doar antetele, fără corpul paginii, deci len(content) este 0
# GET returnează și corpul (tot HTML-ul), deci lungimea este mare.

# ex.19
if len(r_get.cookies) == 0:
    print("Niciun cookie setat")
else:
    for cookie in r_get.cookies:
        print(cookie.name, "- secure:", cookie.secure)

        # ex.20
time.sleep(1) 

session = requests.Session()
session.headers.update({"User-Agent": "WebLab-GhermanLaurentiu"})

response = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
print(response.text)
print("User-Agent trimis:", response.json()["headers"]["User-Agent"])
# response.text este un atribut (o valoare deja calculata)
# iar response.json() este o metoda (o actiune care parseaza corpul ca JSON), de aceea se apeleaza cu paranteze.