# Modul cu funcții reutilizabile pentru lucrul cu pagini web

import csv
import json
import re
import socket
import ssl
import time
import urllib.parse
from datetime import datetime

import requests

TIMEOUT = 10  # secunde
DEFAULT_HEADERS = {"User-Agent": "WebLab-GhermanLaurentiu"}


def fetch(url: str, timeout: int = TIMEOUT) -> requests.Response:
    """Returnează obiectul răspuns pentru adresa url, cu timeout în secunde."""
    response = requests.get(url, headers=DEFAULT_HEADERS, timeout=timeout)
    return response


def get_status(url: str) -> int:
    """Returnează codul de stare HTTP pentru adresa url."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code


def get_title(html: str) -> str | None:
    """Extrage titlul paginii dintr-un șir HTML, sau None dacă lipsește."""
    if "<title>" in html and "</title>" in html:
        start = html.find("<title>") + len("<title>")
        end = html.find("</title>")
        return html[start:end].strip()
    return None


def security_headers(url: str) -> dict:
    """Verifică prezența a cinci antete de securitate și returnează {antet: True/False}."""
    antete = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy",
    ]
    response = requests.get(url, timeout=TIMEOUT)
    rezultat = {}
    for antet in antete:
        rezultat[antet] = antet in response.headers
    return rezultat


def score_headers(results: dict) -> str:
    """Primește dicționarul din security_headers și returnează un șir precum '3/5'."""
    prezente = sum(results.values())
    return f"{prezente}/{len(results)}"


def fetch_robots(base: str) -> str | None:
    """Returnează textul fișierului /robots.txt sau None dacă lipsește."""
    response = requests.get(base + "/robots.txt", timeout=TIMEOUT)
    if response.status_code == 200:
        return response.text
    return None


def disallowed_paths(robots_text: str | None) -> list:
    """Returnează lista valorilor Disallow: din textul robots.txt (listă goală pentru None)."""
    if robots_text is None:
        return []
    cai = []
    for linie in robots_text.splitlines():
        linie = linie.strip()
        if linie.lower().startswith("disallow:"):
            cai.append(linie.split(":", 1)[1].strip())
    return cai


def extract_links(html: str) -> list:
    """Returnează legăturile (href) din codul html, fără duplicate."""
    linkuri = re.findall(r'href="([^"]+)"', html)
    return list(dict.fromkeys(linkuri))


def split_links(links: list, domain: str):
    """Împarte legăturile în două liste: de pe același domeniu și către alte site-uri."""
    interne = []
    externe = []
    baza = "https://" + domain
    for link in links:
        complet = urllib.parse.urljoin(baza, link)
        if urllib.parse.urlparse(complet).netloc == domain:
            interne.append(complet)
        else:
            externe.append(complet)
    return interne, externe


def resolve(hostname: str) -> str:
    """Returnează adresa IP a domeniului hostname, prin interogare DNS."""
    return socket.gethostbyname(hostname)


def cert_days_left(hostname: str) -> int:
    """Returnează câte zile mai sunt până la expirarea certificatului SSL al domeniului."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            certificat = ssock.getpeercert()
    expira = ssl.cert_time_to_seconds(certificat["notAfter"])
    return int((expira - time.time()) / 86400)


def redirect_chain(domain: str) -> list:
    """Returnează lanțul de redirecționări pornind de la http://domeniu, ca texte 'cod -> destinație'."""
    response = requests.get("http://" + domain, headers=DEFAULT_HEADERS, timeout=TIMEOUT)
    lant = []
    for r in response.history:
        lant.append(f"{r.status_code} -> {r.headers.get('Location', '?')}")
    return lant


def check_paths(base: str, paths: list) -> dict:
    """Returnează un dicționar {cale: cod_de_stare} pentru fiecare cale din listă."""
    rezultate = {}
    for cale in paths:
        time.sleep(1)  # pauză între cereri
        rezultate[cale] = get_status(base + cale)
    return rezultate


def save_paths_csv(results: dict, filename: str = "report.csv"):
    """Salvează rezultatele check_paths într-un fișier CSV cu coloanele path, status, checked_at."""
    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["path", "status", "checked_at"])
        for cale, status in results.items():
            writer.writerow([cale, status, datetime.now().isoformat()])


def site_report(url: str, filename: str = "report.json") -> dict:
    """Colectează informații despre site, le afișează și le salvează în report.json."""
    domeniu = urllib.parse.urlparse(url).netloc

    raspuns = fetch(url)
    titlu = get_title(raspuns.text)
    interne, externe = split_links(extract_links(raspuns.text), domeniu)

    try:
        ip = resolve(domeniu)
    except OSError:
        ip = None

    time.sleep(1)  # pauză între cereri
    redirectari = redirect_chain(domeniu)

    time.sleep(1)
    scor = score_headers(security_headers(url))

    try:
        zile = cert_days_left(domeniu)
    except OSError:
        zile = None

    time.sleep(1)
    interzise = disallowed_paths(fetch_robots(url))

    raport = {
        "url": url,
        "status": raspuns.status_code,
        "final_url": raspuns.url,
        "title": titlu,
        "ip": ip,
        "redirects": redirectari,
        "security_score": scor,
        "cert_days_left": zile,
        "internal_links": len(interne),
        "external_links": len(externe),
        "disallowed_paths": interzise,
    }

    def linie(eticheta, valoare):
        print(f"{eticheta:<19}{valoare}")

    print(f"=== Raport site: {url} ===")
    linie("Cod de stare:", raport["status"])
    linie("URL final:", raport["final_url"])
    linie("Titlu:", titlu if titlu else "lipsește")
    linie("Adresă IP:", ip if ip else "indisponibilă")
    linie("Redirecționări:", ", ".join(redirectari) if redirectari else "niciuna")
    linie("Scor securitate:", scor)
    linie("Certificat:", f"{zile} de zile rămase" if zile is not None else "indisponibil")
    linie("Legături:", f"{len(interne)} interne, {len(externe)} externe")
    linie("Căi interzise:", ", ".join(interzise) if interzise else "niciuna")

    with open(filename, "w", encoding="utf-8") as f:
        json.dump(raport, f, indent=2, ensure_ascii=False)
    print(f"Salvat în {filename}")
    return raport


if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))