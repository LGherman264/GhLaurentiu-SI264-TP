# Laborator: funcții, metode și importuri pe web
# Student: Gherman Laurențiu
 
BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

#ex.1
import requests
print(requests.__version__)
import urllib.request

"""
requests este o bibliotecă externă: nu vine cu Python,
așa că a trebuit instalată cu pip.
urllib face parte din biblioteca standard.
"""

#ex.2
import time

# Stil 1:
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Stilul 1:", response.status_code)
time.sleep(1)
#Stil 2:
from requests import get

response = get(BASE_URL, timeout=TIMEOUT)
print("Stilul 2:", response.status_code)

"""
Avantaj import requests: se vede clar de unde vine funcția
(requests.get), deci nu o încurcăm cu alte funcții cu același nume.
Avantaj from requests import get: codul e mai scurt, nu mai scriem
"requests." de fiecare dată.
"""

#ex. 3
import requests as rq
time.sleep(1)

response = rq.get(BASE_URL, timeout=TIMEOUT)
print("Alias rq:", response.status_code)

# Un alias ajută când numele e lung, folosit des și ușor de cunoscut.

#ex. 4
time.sleep(1)

req = urllib.request.Request(BASE_URL, headers={"User-Agent": "WebLab-GhermanLaurențiu"})

with urllib.request.urlopen(req, timeout=TIMEOUT) as response:
    print("Status urllib:", response.status)
    body = response.read().decode("utf-8")

print(body[:200])
#Același rezultat ca înainte, doar că am folosit biblioteca standard (urllib).
# De asemenea, a trebuit să decodez manual corpul răspunsului, apoi să afișez
# primele 200 de caractere din codul html
# urllib a primit 403 din cauza User-Agent-ului implicit, așa că am setat unul propriu cu request

# ex. 5
print(dir(requests))
print(type(requests.post))
print(type(requests.Response))
print(type(requests.adapters))

# post: funcție
# response: clasă
# adapters: modul

#ex.6
time.sleep(1) 

response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Status cu timeout:", response.status_code)
# timeout: parametrul care setează timpul maxim de așteptare, în secunde

#ex.7
time.sleep(1)

start = time.perf_counter()
response = requests.get(BASE_URL, timeout=TIMEOUT)
end = time.perf_counter()
masurat = end - start
print("Măsurat cu perf_counter:", round(masurat, 3), "secunde")
print("response.elapsed:", response.elapsed.total_seconds(), "secunde")
# perf_counter măsoară tot apelul requests.get
# iar response.elapsed doar până la primirea antetelor, deci perf_counter e puțin mai mare.

#ex. 8
try:
    import bs4
except ImportError:
    print("Instalați modulul cu: pip install beautifulsoup4")