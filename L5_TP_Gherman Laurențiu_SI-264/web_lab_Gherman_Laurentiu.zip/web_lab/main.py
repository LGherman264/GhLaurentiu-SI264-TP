import argparse

import webtools
from webtools import check_paths, save_paths_csv

# ex.44 - ex.47: comentate, rezultatele au fost deja verificate
# (vezi exercitiile din raport)

# ex.48
parser = argparse.ArgumentParser(description="Analizează o pagină web.")
parser.add_argument("url", help="adresa paginii, de exemplu https://cybercor.org")
args = parser.parse_args()
url = args.url

# ex.50
webtools.site_report(url)

# ex.49
rezultate = check_paths(url, ["/", "/robots.txt", "/sitemap.xml"])
save_paths_csv(rezultate)
print("Salvat în report.csv")